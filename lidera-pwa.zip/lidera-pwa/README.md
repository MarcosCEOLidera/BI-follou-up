# 📱 Lidera Imóveis — App de Leads

## Como colocar no ar (passo a passo)

---

### ✅ Pré-requisitos (instalar uma vez)

1. **Node.js** — baixe em https://nodejs.org (versão LTS)
2. **Conta no GitHub** — https://github.com (grátis)
3. **Conta no Vercel** — https://vercel.com (grátis, entre com o GitHub)

---

### 🚀 Deploy em 3 passos

#### Passo 1 — Subir o código no GitHub

1. Vá em https://github.com/new
2. Crie um repositório chamado `lidera-leads` (privado recomendado)
3. Clique em **"uploading an existing file"**
4. Arraste **toda a pasta** `lidera-pwa` para lá
5. Clique em **Commit changes**

#### Passo 2 — Conectar ao Vercel

1. Acesse https://vercel.com e faça login com GitHub
2. Clique em **"Add New Project"**
3. Selecione o repositório `lidera-leads`
4. Clique em **Deploy** (as configurações já estão prontas no `vercel.json`)
5. Em ~1 minuto o app estará no ar em uma URL como `lidera-leads.vercel.app`

#### Passo 3 — Domínio personalizado (opcional)

No painel do Vercel → Settings → Domains → adicione `leads.lideraimoveis.com.br`

---

### 📲 Como a equipe instala no celular

#### iOS (iPhone/iPad):
1. Abrir o link no **Safari** (obrigatório, não funciona no Chrome iOS)
2. Tocar no ícone de **compartilhar** (quadrado com seta para cima)
3. Tocar em **"Adicionar à Tela de Início"**
4. Confirmar — o ícone aparece na tela igual um app nativo ✅

#### Android:
1. Abrir o link no **Chrome**
2. Tocar nos 3 pontinhos → **"Adicionar à tela inicial"**
3. Confirmar ✅

---

### 🔄 Como atualizar o app

1. Edite os arquivos no GitHub (ou re-faça o upload)
2. O Vercel faz o deploy automático em ~1 minuto
3. **A equipe não precisa fazer nada** — o app atualiza sozinho na próxima abertura

---

### 💾 Sobre os dados

Os dados ficam salvos **localmente no celular de cada corretor** (React state + localStorage no navegador). Isso significa:
- Funciona offline ✅
- Se o corretor trocar de celular ou limpar o cache, os dados são perdidos ⚠️

**Para salvar os dados em nuvem** (todos veem o mesmo estado em tempo real), o próximo passo seria integrar com Firebase ou Supabase — podemos fazer isso depois se precisar.

---

### 🔑 Credenciais

| Corretor | Senha |
|----------|-------|
| Marcos | 1234 |
| Gabriel Alves | 1234 |
| Gabriel Cipriandi | 1234 |
| Mari | 1234 |
| Leonardo | 1234 |
| Lorenzo | 1234 |
| Everton | 1234 |
| Kleber | 1234 |
| Admin | admin123 |

---

### 🛠 Desenvolvimento local (opcional)

```bash
# Na pasta lidera-pwa:
npm install
npm run dev
# Abre em http://localhost:5173
```
